﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeamTasker.Core;
using TeamTasker.Views;

namespace TeamTasker.ViewModels
{
    class MainViewModel:ObservableObject
    {
        public RelayCommand SignViewCommand { get; set; }
        public RelayCommand RegViewCommand { get; set; }
        public SignViewModel SignViewModel { get; set; }
        public RegViewModel RegViewModel { get; set; }
        private object _currentView;
        public object CurrentView
        {
            get { return _currentView; }
            set 
            { 
                _currentView = value;
                OnPropertyChanged();
            }
        }
        public MainViewModel()
        {
            SignViewModel=new SignViewModel();
            RegViewModel = new RegViewModel();
            CurrentView = SignViewModel;
            SignViewCommand = new RelayCommand(o =>
            {
                CurrentView= SignViewModel;
            });
            RegViewCommand = new RelayCommand(o =>
            {
                CurrentView = RegViewModel;
            });
        }

    }
}
