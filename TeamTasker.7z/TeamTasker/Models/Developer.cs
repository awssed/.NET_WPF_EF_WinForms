﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace TeamTasker
{
    public enum Position
    {
        Junior,
        Middle,
        Senior
    }

    public class Developer : IDataErrorInfo
    {
        public string Login { get; set; }
        public string Name { get; set; }
        public BitmapImage Image { get; set; }
        public Position Position { get; set; }
        public string Email { get; set; }
        public string Password { get; set; } // Добавленное поле Password
        public List<string> Skills { get; set; }
        public bool isAdmin { get; set; }

        public Developer(string login, string name, Position position, string email, string password, byte[] image, bool isAdmin)
        {
            Login = login;
            Name = name;
            Position = position;
            if (image != null && image.Length > 0)
            {
                using (var memoryStream = new MemoryStream(image))
                {
                    Image = new BitmapImage();
                    Image.BeginInit();
                    Image.CacheOption = BitmapCacheOption.OnLoad;
                    Image.StreamSource = memoryStream;
                    Image.EndInit();
                }
            }
            if (image == null)
            {
                Image = new BitmapImage(new Uri("file:///D:/Учёба/4сем/ОПП/Lab8/Images/defaultPerson.png"));
            }
            Email = email;
            Password = password;
            Skills = new List<string>();
            this.isAdmin = isAdmin;
        }

        public string this[string columnName]
        {
            get
            {
                string error = String.Empty;
                switch (columnName)
                {
                    case "Name":
                        Regex regex = new Regex(@"^[А-ЯЁ][а-яё]+\s[А-ЯЁ][а-яё]+\s[А-ЯЁ][а-яё]+$");
                        if (!regex.IsMatch(Name))
                        {
                            error = "Incorrect name";
                        }
                        break;
                    case "Email":
                        // Дополнительная проверка валидности email
                        if (!IsValidEmail(Email))
                        {
                            error = "Invalid email";
                        }
                        break;
                    case "Login":
                        if (string.IsNullOrWhiteSpace(Login))
                        {
                            error = "Invalid login";
                        }
                        break;
                    case "Password":
                        if (string.IsNullOrWhiteSpace(Password))
                        {
                            error = "Invalid password";
                        }
                        break;
                }
                return error;
            }
        }

        [JsonIgnore]
        public string Error
        {
            get { throw new NotImplementedException(); }
        }

        public Developer(string login, string name, string password)
        {
            Login = login;
            Name = name;
            Password = password;
            Image = new BitmapImage(new Uri("file:///D:/Учёба/4сем/ОПП/Lab8/Images/defaultPerson.png")); Skills = new List<string>();
        }
        public Developer(string login, string name,Position position, string password)
        {
            Login = login;
            Name = name;
            Position = position;
            Password = password;
            Image = new BitmapImage(new Uri("file:///D:/Учёба/4сем/ОПП/Lab8/Images/defaultPerson.png")); Skills = new List<string>();
        }

        public Developer()
        {
            Login = "";
            Name = String.Empty;
            Position = Position.Junior;
            Image = new BitmapImage(new Uri("file:///D:/Учёба/4сем/ОПП/Lab8/Images/defaultPerson.png")); Skills = new List<string>();
        }



        private bool IsValidEmail(string email)
        {
            // Проверка валидности email с использованием регулярного выражения или других методов
            // В этом примере используется простая проверка на наличие символа @
            return email.Contains("@");
        }
    }
}
